# -*- coding: utf-8 -*-
"""
validation.py

O bridge aceita SOMENTE geometria em mm e parametros de corte.
Nunca PDF, imagem, pixels, caminho de arquivo ou comando de shell.
"""

from usbprint import CameoError

A4_W_MM = 297.0
A4_H_MM = 210.0

RANGES = {
    "depth": (1, 10),
    "force": (1, 33),
    "speed": (1, 10),
    "passes": (1, 5),
}

SHEET_MIN_MM = 50.0
SHEET_MAX_MM = 1000.0

ALLOWED_JOB_KEYS = {
    "sheet", "sheetWidthMm", "sheetHeightMm", "cards", "settings",
    "depth", "force", "speed", "passes",
    "radiusMm", "lineOvercut", "lineOvercutMm",
}


def _int_in_range(payload, key):
    value = payload.get(key)
    low, high = RANGES[key]
    if not isinstance(value, int) or isinstance(value, bool):
        raise CameoError(f"Parâmetro inválido: {key}.")
    if not low <= value <= high:
        raise CameoError(f"Parâmetro fora da faixa permitida: {key}.")
    return value


def validate_job(payload):
    if not isinstance(payload, dict):
        raise CameoError("Requisição inválida.")

    unknown = set(payload.keys()) - ALLOWED_JOB_KEYS
    if unknown:
        raise CameoError("A requisição contém campos não permitidos.")

    settings = payload.get("settings")
    if not isinstance(settings, dict):
        settings = payload

    depth = _int_in_range(settings, "depth")
    force = _int_in_range(settings, "force")
    speed = _int_in_range(settings, "speed")
    passes = _int_in_range(settings, "passes")

    radius = settings.get("radiusMm", 0)
    if not isinstance(radius, (int, float)) or isinstance(radius, bool):
        raise CameoError("Parâmetro inválido: raio.")
    if not 0 <= float(radius) <= 10:
        raise CameoError("Parâmetro fora da faixa permitida: raio.")

    line_overcut = bool(settings.get("lineOvercut", False))
    line_overcut_mm = settings.get("lineOvercutMm", 0.1)
    if not isinstance(line_overcut_mm, (int, float)) or isinstance(line_overcut_mm, bool):
        raise CameoError("Parâmetro inválido: sobrecorte de linha.")
    if not 0 <= float(line_overcut_mm) <= 1.0:
        raise CameoError("Parâmetro fora da faixa permitida: sobrecorte de linha.")

    def _sheet_dim(key, default):
        value = payload.get(key, default)
        if not isinstance(value, (int, float)) or isinstance(value, bool):
            raise CameoError("Tamanho de folha inválido.")
        value = float(value)
        if not SHEET_MIN_MM <= value <= SHEET_MAX_MM:
            raise CameoError("Tamanho de folha fora da faixa permitida.")
        return value

    sheet_w = _sheet_dim("sheetWidthMm", A4_W_MM)
    sheet_h = _sheet_dim("sheetHeightMm", A4_H_MM)

    raw_cards = payload.get("cards")
    if not isinstance(raw_cards, list) or not raw_cards:
        raise CameoError("Nenhuma carta selecionada.")
    if len(raw_cards) > 200:
        raise CameoError("Quantidade de cartas acima do limite.")

    cards = []
    for card in raw_cards:
        if not isinstance(card, dict):
            raise CameoError("Geometria de carta inválida.")
        try:
            x0 = float(card["x0Mm"] if "x0Mm" in card else card["x0"])
            y0 = float(card["y0Mm"] if "y0Mm" in card else card["y0"])
            x1 = float(card["x1Mm"] if "x1Mm" in card else card["x1"])
            y1 = float(card["y1Mm"] if "y1Mm" in card else card["y1"])
        except (KeyError, TypeError, ValueError):
            raise CameoError("Geometria de carta inválida.")

        if not (x1 - x0 > 1.0 and y1 - y0 > 1.0):
            raise CameoError("Uma carta tem tamanho inválido.")
        if not (0 <= x0 < x1 <= sheet_w and 0 <= y0 < y1 <= sheet_h):
            raise CameoError("Uma carta está fora da folha.")

        cards.append((x0, y0, x1, y1))

    sheet = payload.get("sheet", 1)
    if not isinstance(sheet, int) or isinstance(sheet, bool) or sheet < 1:
        raise CameoError("Número de folha inválido.")

    return {
        "sheet": sheet,
        "sheet_w_mm": sheet_w,
        "sheet_h_mm": sheet_h,
        "cards": cards,
        "depth": depth,
        "force": force,
        "speed": speed,
        "passes": passes,
        "radius_mm": float(radius),
        "line_overcut": line_overcut,
        "line_overcut_mm": float(line_overcut_mm),
    }
